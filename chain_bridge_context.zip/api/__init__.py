"""
Benson API

This package provides REST API endpoints for module interaction and extensibility.
"""

__all__ = []
