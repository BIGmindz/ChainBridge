"""Backtesting module for the trading bot."""
