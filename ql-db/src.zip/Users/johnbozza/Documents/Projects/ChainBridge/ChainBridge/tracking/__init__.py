"""
Business Impact Tracking

This package provides metrics collection and business impact tracking
for the Benson modular architecture.
"""

__all__ = []
