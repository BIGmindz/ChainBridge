"""
Tests for ChainPay Smart Settlements service.
"""
