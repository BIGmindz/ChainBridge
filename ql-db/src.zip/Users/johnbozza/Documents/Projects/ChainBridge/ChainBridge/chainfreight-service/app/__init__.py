"""ChainFreight Service - Shipment lifecycle and supply chain execution."""
