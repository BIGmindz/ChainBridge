"""OC (Operator Console) core package."""
